from .generator import create_document
